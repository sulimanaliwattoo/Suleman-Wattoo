"use client";
import { useState, useEffect, useTransition } from "react";
import {
  addSiteAction,
  deleteSiteAction,
  getSitesAction,
  checkGA4PropertyAccess,
  type GA4AccessResult,
} from "@/lib/server-actions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import {
  Trash2Icon,
  PlusIcon,
  CopyIcon,
  CheckCheckIcon,
  Loader2Icon,
} from "lucide-react";
import type { Sites, User } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Client_Email } from "@/lib/utils";
import { authClient } from "@/lib/auth-client";

export default function SitesPage() {
  const [sites, setSites] = useState<Sites[]>([]);
  const [loadingSites, setLoadingSites] = useState(false);
  const [url, setUrl] = useState("");
  const [propertyId, setPropertyId] = useState("");
  const [adding, setAdding] = useState(false);
  const [deletingDomain, setDeletingDomain] = useState<string | null>(null);
  const [emailCopied, setEmailCopied] = useState(false);
  const [results, setResults] = useState<GA4AccessResult[]>([]);
  const [isPending, startTransition] = useTransition();

  const runCheck = () => {
    const PROPERTY_IDS = sites.map((site) => site.propertyId);
    startTransition(async () => {
      const data = await checkGA4PropertyAccess(PROPERTY_IDS);
      setResults(data);
    });
  };

  useEffect(() => {
    getSitesAction().then(setSites);
  }, []);

  useEffect(() => {
    if (sites.length > 0) {
      runCheck();
    }
  }, [sites]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdding(true);
    try {
      await addSiteAction(url, propertyId);
      toast.success("Site added successfully");
      setUrl("");
      setPropertyId("");
      setLoadingSites(true);
      setSites(await getSitesAction());
      setLoadingSites(false);
    } catch (err) {
      toast.error(
        `Failed: ${err instanceof Error ? err.message : "Unknown error"}`,
      );
    } finally {
      setAdding(false);
    }
  };

  const handleDelete = async (domain: string): Promise<void> => {
    setDeletingDomain(domain);
    await deleteSiteAction(domain);
    const { data, error } = await authClient.admin.listUsers({
      query: {
        filterField: "accessibleSites",
        filterOperator: "contains",
        filterValue: domain,
      },
    });
    if (error) {
      toast.error(`Failed to fetch users: ${error.message}`);
      return;
    }
    const usersWithAccess = data.users as User[];
    for (const user of usersWithAccess) {
      const updatedSites = user.accessibleSites.filter(
        (site) => site !== domain,
      );
      const { error } = await authClient.admin.updateUser({
        userId: user.id,
        data: { accessibleSites: updatedSites },
      });
      if (error) {
        toast.error(`Failed to update user ${user.email}: ${error.message}`);
      } else {
        toast.success(`Updated user ${user.email} access`);
      }
    }
    setLoadingSites(true);
    setSites(await getSitesAction());
    setLoadingSites(false);
    setDeletingDomain(null);
    toast.success("Site removed");
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(Client_Email);
    // check if the email was copied successfully then make the button text "Copied!" for 2 seconds
    if (navigator.clipboard) {
      setEmailCopied(true);
      toast.success("Email copied to clipboard");
      setTimeout(() => setEmailCopied(false), 2000);
    } else {
      toast.error("Failed to copy email");
    }
  };

  return (
    <div className="container mx-auto p-5 space-y-6">
      <h1 className="text-2xl font-bold">Manage Sites</h1>

      <Card>
        <CardHeader>
          <CardTitle>Add New Site</CardTitle>
          <CardDescription>
            In order to get data from Google analytics,
            <br />
            Visit Google Analytics &gt; Admin &gt; Property Access Management
            &gt; Add Users &gt; Add the service email below with atleast
            &quot;Viewer&quot; role
            <Badge variant={"outline"} className="ml-2 my-2 py-4">
              <p className="text-wrap">{Client_Email} </p>
              <Button
                variant={"outline"}
                size={"icon-xs"}
                onClick={() => handleCopyEmail()}
                disabled={emailCopied}
              >
                {" "}
                {emailCopied ? <CheckCheckIcon /> : <CopyIcon />}
              </Button>
            </Badge>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAdd}>
            <FieldGroup>
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <FieldLabel>Site URL</FieldLabel>
                  <Input
                    placeholder="https://example.com"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    required
                  />
                </Field>
                <Field>
                  <FieldLabel>GA4 Property ID</FieldLabel>
                  <Input
                    placeholder="123456789"
                    value={propertyId}
                    onChange={(e) => setPropertyId(e.target.value)}
                    required
                  />
                </Field>
              </div>
              <Button type="submit" disabled={adding}>
                <PlusIcon /> {adding ? "Adding..." : "Add Site"}
              </Button>
            </FieldGroup>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>All Sites ({sites.length})</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {sites.map((site) => (
            <div
              key={site.domain}
              className="flex items-center justify-between p-3 border rounded-none flex-wrap gap-3"
            >
              <div className="flex items-center gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={site.favicon} />
                  <AvatarFallback>{site.domain[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">{site.domain}</p>
                  <p className="text-xs text-muted-foreground">
                    Property: {site.propertyId}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {isPending && (
                  <Loader2Icon size={14} className="animate-spin" />
                )}
                {!isPending &&
                results.find((result) => result.propertyId === site.propertyId)
                  ?.hasAccess ? (
                  <Badge
                    variant="outline"
                    className="border-green-500 text-green-500"
                  >
                    Access
                  </Badge>
                ) : (
                  <Badge
                    variant="outline"
                    className="border-red-500 text-red-500"
                  >
                    Denied
                  </Badge>
                )}
                <Button
                  variant="destructive"
                  size="icon-sm"
                  onClick={() => handleDelete(site.domain)}
                  disabled={deletingDomain === site.domain}
                >
                  {deletingDomain === site.domain ? (
                    <Loader2Icon className="animate-spin" />
                  ) : (
                    <Trash2Icon />
                  )}
                </Button>
              </div>
            </div>
          ))}
          {!loadingSites && sites.length === 0 && (
            <p className="text-center text-muted-foreground py-6">
              No sites added yet.
            </p>
          )}
          {loadingSites && <Loader2Icon className="animate-spin w-full" />}
        </CardContent>
      </Card>
    </div>
  );
}
