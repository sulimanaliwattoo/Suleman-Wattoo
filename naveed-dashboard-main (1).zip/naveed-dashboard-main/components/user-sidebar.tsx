"use client";

import { NavMain } from "@/components/nav-main";
import { NavUser } from "@/components/nav-user";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar";
import {
  BarChart3Icon,
  DollarSignIcon,
  ExternalLinkIcon,
  HomeIcon,
} from "lucide-react";
import Link from "next/link";

interface UserSidebarProps {
  user: {
    name?: string;
    email: string;
    image?: string | null;
    accessibleSites?: string[];
  };
  sites: {
    domain: string;
    url: string;
    favicon: string;
  }[];
}

export function UserSidebar({ user, sites }: UserSidebarProps) {
  const navItems = [
    {
      title: "Dashboard",
      url: "/dashboard",
      icon: <HomeIcon className="h-4 w-4" />,
    },
    {
      title: "Earnings",
      url: "/dashboard/earnings",
      icon: <DollarSignIcon className="h-4 w-4" />,
    },
    {
      title: "Payments",
      url: "/dashboard/payments",
      icon: <BarChart3Icon className="h-4 w-4" />,
    },
    {
      title: "UTM Tracking",
      url: "#",
      icon: <ExternalLinkIcon className="h-4 w-4" />,
      items: sites.map((site) => ({
        title: site.domain,
        url: `/dashboard/utm-tracking-links?site=${site.domain}`,
      })),
    },
  ];

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <Link href="/">
              <SidebarMenuButton
                size="lg"
                className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
              >
                <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
                  <BarChart3Icon className="h-4 w-4" />
                </div>
                <div className="grid flex-1 text-left text-sm leading-tight">
                  <span className="truncate font-semibold">
                    User Dashboard
                  </span>
                  <span className="truncate text-xs">Analytics & Earnings</span>
                </div>
              </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent>
        <NavMain items={navItems} />
      </SidebarContent>
      <SidebarFooter>
        <NavUser
          user={{
            name: user.name || "User",
            email: user.email,
            avatar: user.image || "",
          }}
        />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
